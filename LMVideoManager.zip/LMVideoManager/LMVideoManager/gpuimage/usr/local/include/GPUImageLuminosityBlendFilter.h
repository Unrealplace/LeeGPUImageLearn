#import "GPUImageTwoInputFilter.h"

@interface GPUImageLuminosityBlendFilter : GPUImageTwoInputFilter

@end
