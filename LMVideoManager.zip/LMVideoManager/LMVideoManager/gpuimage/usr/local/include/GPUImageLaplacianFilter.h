#import "GPUImage3x3ConvolutionFilter.h"

@interface GPUImageLaplacianFilter : GPUImage3x3ConvolutionFilter

@end
