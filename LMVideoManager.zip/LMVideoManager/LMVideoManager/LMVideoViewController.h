//
//  LMVideoViewController.h
//  TopicEdit
//
//  Created by 张利民 on 2017/8/9.
//  Copyright © 2017年 ghostlord. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LMVideoViewController : UIViewController

@end
