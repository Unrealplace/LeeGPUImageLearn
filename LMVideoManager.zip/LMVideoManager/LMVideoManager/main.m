//
//  main.m
//  LMVideoManager
//
//  Created by 张利民 on 2017/8/9.
//  Copyright © 2017年 张利民. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
